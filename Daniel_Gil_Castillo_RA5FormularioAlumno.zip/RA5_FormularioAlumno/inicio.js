// funcion que se ejecuta cuando se asegura que el DOM esta cargarfo
window.onload = empezar

// arrays para almacenar informacion territorial
arrayPaises = []
arrayProvincias = []
arrayPoblaciones = []

function empezar() {
    // SE AÑADEN LISTENERS A LOS BOTONES Y A LOS SELECT 
    document.getElementById("boton_enviar").addEventListener("click", boton_enviar_pulsado)
    document.getElementById("pais").addEventListener("change", pais_cambiado)
    document.getElementById("provincia").addEventListener("change", provincia_cambiada)

    // SE RELLENAN AQUI LOS SELECT LEYENDO LOS JSON
    rellenarSelectConJson('./json/lenguaMaterna.json', "lenguamaterna1")
    rellenarSelectConJson('./json/idiomasEstudiados.json', "idiomas")

    rellenarSelectConJson('./json/profesion.json', "profesion2")
    rellenarSelectConJson('./json/ciudadNacimiento.json', "ciudadNacimiento")
    rellenarSelectConJson('./json/lenguaMaterna.json', "lenguamaterna2")
    rellenarSelectConJson('./json/idiomas.json', "idiomasConocidos")

    rellenarSelectConJson('./json/pais.json', "pais")

    rellenarSelectConJson('./json/idiomasEstudiados.json', "idiomasEstudiados")
    rellenarSelectConJson('./json/nivelEstudio.json', "nivelEstudios")
    rellenarSelectConJson('./json/nivelEstudioSol.json', "estudiosSolicitado")

    rellenarSelectConJson('./json/alergias.json', "alergias")

    leerJsonYCrearArrayProvincias('./json/provincia.json')
    leerJsonYCrearArrayPoblaciones('./json/poblacion.json')

    // listener para el botón de enviar
    document.getElementById('boton_enviar').addEventListener('click', boton_enviar_pulsado);

}


// FUNCION GENERICA PARA RELLENAR UN SEELCT A PARTIR DE LOS DATOS DE UN JSON
// No se usa con los select de provincias y poblaciones pues tienen su funcion especial para ellos
function rellenarSelectConJson(ficheroJson, idDelElementoSelectParaRellenar) {
    // SE RELLENAN AQUI LOS SELECT LEYENDO LOS JSON
    fetch(ficheroJson)
        // el primer .then confirma que se ha podido hacer la peticion y la construye
        .then(response => {
            if (!response.ok) {
                alert('Error al cargar el archivo JSON');
            }
            return response.json();
        })
        // RECIBIMOS LA LECTURA LA COMPLETADA DEL FICHERO JSON
        .then(data => {
            // Iterar sobre las opciones y a単adirlas al select
            data.opciones.forEach(opcion => {
                optionElement = document.createElement('option');
                optionElement.value = opcion.valor;
                optionElement.textContent = opcion.texto;
                document.getElementById(idDelElementoSelectParaRellenar).appendChild(optionElement);
            });
        })
        .catch(error => {
            //          console.error('Error:', error)
        });
}

// SE RELLENA AQUI EL SELECT LEYENDO JSON PROVINCIAS
function leerJsonYCrearArrayProvincias(ficheroJson) {  
    fetch(ficheroJson)
        // el primer .then confirma que se ha podido hacer la peticion y la construye
        .then(response => {
            if (!response.ok) {
                alert('Error al cargar el archivo JSON');
            }
            return response.json();
        })
        // EN EL SEGUNDO .then RECIBIMOS LA LECTURA LA COMPLETADA DEL FICHERO JSON
        .then(data => {
            arrayProvincias = data.opciones
            rellenarSelectProvincia("ITALIA")

        })
        .catch(error => {
            console.error('Error:', error);
            selectElement.innerHTML = '<option>Error al cargar las opciones</option>';
        });
}

// SE RELLENA AQUI EL SELECT LEYENDO JSON POBLACIONES
function leerJsonYCrearArrayPoblaciones(ficheroJson) {
    fetch(ficheroJson)
        // el primer .then confirma que se ha podido hacer la peticion y la construye
        .then(response => {
            if (!response.ok) {
                alert('Error al cargar el archivo JSON');
            }
            return response.json();
        })
        // EN EL SEGUNDO .then RECIBIMOS LA LECTURA LA COMPLETADA DEL FICHERO JSON
        .then(data => {
            arrayPoblaciones = data.opciones
            rellenarSelectPoblacion("SICILIA")
        })
        .catch(error => {
            console.error('Error:', error);
            selectElement.innerHTML = '<option>Error al cargar las opciones</option>';
        });
}

// FUNCION QUE SE EJECUTA CUANDO SE HA CAMBIADO LA PROVINCIA
function provincia_cambiada() {
    selectedOption = this.options[this.selectedIndex];
    selectedValue = selectedOption.value;
    selectedText = selectedOption.text;
    nuevaprov = selectedText
    rellenarSelectPoblacion(nuevaprov)
}

// FUCION QUE RELLENA EL SELECT DE POBLACION CUANDO SE CAMBIA LA PROVINCIA
function rellenarSelectPoblacion(nuevaprov) {
    resultado = []
    for (pobl of arrayPoblaciones) {
        if (pobl.provincia == nuevaprov) {
            resultado.push(pobl)
        }
    };

    document.getElementById("poblacion").innerHTML = "";
    for (prov of resultado) {
        optionElement = document.createElement('option');
        optionElement.value = prov.valor;
        optionElement.textContent = prov.texto;
        document.getElementById("poblacion").appendChild(optionElement);
    };
}

// FUNCION QUE ANALIZA SI SE HA CAMBIADO EL PAIS
function pais_cambiado(evento) {
    selectedOption = this.options[this.selectedIndex];
    selectedValue = selectedOption.value;
    selectedText = selectedOption.text;
    nuevopais = selectedText
    rellenarSelectProvincia(nuevopais)
}

// FUCION QUE RELLENA EL SELECT DE PROVINCIA CUANDO SE CAMBIA EL PAIS
function rellenarSelectProvincia(nuevopais) {
    resultado = []
    for (prov of arrayProvincias) {
        if (prov.pais == nuevopais) {
            resultado.push(prov)
        }
    };
    document.getElementById("provincia").innerHTML = "";
    for (prov of resultado) {
        optionElement = document.createElement('option');
        optionElement.value = prov.valor;
        optionElement.textContent = prov.texto;
        document.getElementById("provincia").appendChild(optionElement);
    }
    primeraprov = resultado[0].texto
    rellenarSelectPoblacion(primeraprov)
}

// SE EJECUTA AL PULSAR EL BOTON ENVIAR, 
// HACE LAS VALIDACIONES DE LOS CAMPOS 
// Y EMITE LA VENTANA DEL RESULTADO
function boton_enviar_pulsado(e) {
    e.preventDefault()   // evita que en HTML el boton del formulario funcione y envia a otra pagina

    // LLAMAMOS A LA FUNCION QUE VALIDA EL CONTENIDO DE TODOS LOS CAMPOS
    let resultadoValidar = validar()
    // SI LA FUNCION DE VALIDAR HA IDO BIEN....
    if (resultadoValidar == true) {
        // CONSTRUIMOS UN OBJETO ALUMNO USANDO EL PATRON BUILDER
        // creamos primero un alumno basico (vacio)
        let builder = new AlumnoBuilder();
        // con los distintos builder, uno a uno, vamos añadiendo los datos del alumno
        let alumno = builder
            .buildDatosPersonales()
            .buildFamiliares()
            .buildDireccion()
            .buildDatosAcademicos()
            .buildInformacionMedica()
            .build();
        // CON EL ALUMNO YA CREADO, MOSTRAMOS LA VENTANA DEL RESUMEN
        mostrarResumen(alumno);
    }
}

// FUCION DE VALIDACION DE CAMPOS
function validar() {
    // BORRRAMOS TODOS LOS MENSAJES PREVIOS DE ERROR QUE HUBIERAN SALIDO
    document.getElementById("errornombre").innerHTML = ""
    document.getElementById("errorapellidos").innerHTML = ""
    document.getElementById("errornif").innerHTML = ""
    document.getElementById("errornom2").innerHTML = ""
    document.getElementById("errorapellido2").innerHTML = ""
    document.getElementById("errornif2").innerHTML = ""
    document.getElementById("errorDireccion").innerHTML = ""
    document.getElementById("errorPost").innerHTML = ""
    document.getElementById("errorCol").innerHTML = ""
    document.getElementById("errorMed").innerHTML = ""


    // COMPROMAMOS SI FALTA ALGUN VALOR
    
    // cogemos el valor de la caja input del campo nombre 
    contenido_nombre = document.getElementById("nombre").value
    // miramos si, quitandole espacios en blanco, esta vacio
    if (contenido_nombre.trim() == "") {
        // si esta vacio, ponemos en el div de error el texto del error
        document.getElementById("errornombre").innerHTML = "Debe rellenar este campo"
        // salimos del metodo devolviendo FALSE; esto es, que no vale la validacion
        return false
    }

    // las siguientes comprobaciones son iguales que la anterior, para otros campos
    contenido_apellidos = document.getElementById("apellidos").value
    if (contenido_apellidos.trim() == "") {
        document.getElementById("errorapellidos").innerHTML = "Debe rellenar este campo"
        return false
    }

    contenido_nif = document.getElementById("nif").value
    if (contenido_nif.trim() == "") {
        document.getElementById("errornif").innerHTML = "Debe rellenar este campo"
        return false
    }

    contenido_n = document.getElementById("nombre2").value
    if (contenido_n.trim() == "") {
        document.getElementById("errornom2").innerHTML = "Debe rellenar este campo"
        return false
    }

    contenido_apellido2 = document.getElementById("apellido2").value
    if (contenido_apellido2.trim() == "") {
        document.getElementById("errorapellido2").innerHTML = "Debe rellenar este campo"
        return false
    }

    contenido_nif2 = document.getElementById("nif2").value
    if (contenido_nif2.trim() == "") {
        document.getElementById("errornif2").innerHTML = "Debe rellenar este campo"
        return false
    }

    contenido_direccionC = document.getElementById("direccionC").value
    if (contenido_direccionC.trim() == "") {
        document.getElementById("errorDireccion").innerHTML = "Debe rellenar este campo"
        return false
    }

    contenido_codigoP = document.getElementById("codigoP").value
    if (contenido_codigoP.trim() == "") {
        document.getElementById("errorPost").innerHTML = "Debe rellenar este campo"
        return false
    }

    contenido_colP = document.getElementById("colP").value
    if (contenido_colP.trim() == "") {
        document.getElementById("errorCol").innerHTML = "Debe rellenar este campo"
        return false
    }

    contenido_medAct = document.getElementById("medAct").value
    if (contenido_medAct.trim() == "") {
        document.getElementById("errorMed").innerHTML = "Debe rellenar este campo"
        return false
    }

    // comprobamos que el nif tiene formato valido. Usamos la funcion validarNIF
    // cogemos el valor de la caja input del nif
    nifDado = document.getElementById("nif").value;
    // lo pasamos a mayusculas para que al validar el nif valga tanto en mayusculas como minusculas
    nifDado = nifDado.toUpperCase()
    // validamos el nif 
    esvalido = validarNIF(nifDado)
    // emitimos mensaje de error si el nif no vale
    if (esvalido == false) {
        alert("El NIF personal no tiene un formato válido. Debe tener 8 números y una letra")
        return false
    }

    // validamos el segundo nif, con el mismo procedimiento que el anterior
    nifDado = document.getElementById("nif2").value;
    nifDado = nifDado.toUpperCase()
    esvalido = validarNIF(nifDado)
    if (esvalido == false) {
        alert("El NIF del familiar no tiene un formato válido. Debe tener 8 números y una letra")
        return false
    }

    // comprobamos que el codigo postal tiene formato valido. Usamos la funcion validarCodigoPostal
    // validamos el cp
    esvalidocp = validarCodigoPostal(contenido_codigoP)
    if (esvalidocp == false) {
        // emitimos mensaje de error si el cp no vale
        alert("El C.Postal no tiene un formato válido. Debe tener 8 números y una letra")
        return false
    }
    
    // salimos del metodo devolviendo TRUE; 
    // esto es, no nos hemos salido antes con ningun return FALSE
    // por lo que no ha habido errores previos
    return true;
}

// FUNCION QUE VALIDA EL CODIGO POSTAL
function validarCodigoPostal(codigoPostal) {
    // Expresión regular para validar código postal
    const regex = /^[0-9]{5}$/;
    // Comprobamos que el codigi postal recibido coincide con la expresion regular
    if (regex.test(codigoPostal)) {
        return true; // Código postal válido
    } else {
        return false; // Código postal inválido
    }
}

function validarNIF(nif) {
    // Eliminamos espacios en blanco y convertimos a mayúsculas
    nif = nif.trim().toUpperCase();
    // Comprobamos que el nif recibido coincide con la expresion regular valida para un nif
    // En la expresionc comprobamos si tiene el formato correcto (8 números y una letra)
    if (/^[0-9]{8}[A-Z]$/.test(nif)) {
        // el nif tiene formato valido, pasamos valdar la letra
        // Extraemos el número y la letra
        const numero = nif.substring(0, 8);
        const letra = nif.charAt(8);
        // Calculamos el resto de la división entre 23
        const resto = numero % 23;
        // Array con las letras correspondientes a cada resto
        const letras = 'TRWAGMYFPDXBNJZSQVHLCKE';
        // Comparamos la letra calculada con la letra del NIF
        esletravalida =  letras.charAt(resto) === letra;
        return esletravalida;
    } else {
        return false;
    }
}

//=============== IMPLEMENTACION DE OBJETOS ============

// Clase Alumno Base
function Alumno() { }

// a la clase base, usando prototypes, le vamos añadiendo propiedades
// se crean las propiedades, pero no se les da aun valor
// asi se crea la propiedad datosPersonales  
Alumno.prototype.setDatosPersonales = function (datos) {
    this.datosPersonales = datos;
    return this;
};
// asi los datos familiares 
Alumno.prototype.setFamiliares = function (familiares) {
    this.familiares = familiares;
    return this;
};
// asi los datos de direccion
Alumno.prototype.setDireccion = function (direccion) {
    this.direccion = direccion;
    return this;
};
// asi los datos academicos
Alumno.prototype.setDatosAcademicos = function (datosAcademicos) {
    this.datosAcademicos = datosAcademicos;
    return this;
};
// asi los datos medicos
Alumno.prototype.setInformacionMedica = function (informacionMedica) {
    this.informacionMedica = informacionMedica;
    return this;
};


// esta funcion builder es la que crea un alumno vacio inicialmente
AlumnoBuilder.prototype.build = function () {
    return this.alumno;
};

// Cremos un Builder para la clase Alumno
function AlumnoBuilder() {
    this.alumno = new Alumno();
}

// Se crea (y se añade al Alumno) la funcion para construir el contenido de los datos personales 
// cada valor de los datos personales se saca de las etiquetas HTML del formulario
AlumnoBuilder.prototype.buildDatosPersonales = function () {
    // asi se seca del HTML el valor del campo idiomas que es multiselect
    var selectIdiomas = document.getElementById('idiomas');
    var opcionesIdiomas = selectIdiomas.selectedOptions;
    var idiomas = [];
    for (var i = 0; i < opcionesIdiomas.length; i++) {
        idiomas.push(opcionesIdiomas[i].innerHTML);
    }

   // asi se seca del HTML el valor del campo lengua maternal
    var select = document.getElementById('lenguamaterna1');
    var lenguamaterna1 = select.options[select.selectedIndex].text;

    this.alumno.setDatosPersonales({
       // asi se saca del HTML el valor de los campos nomnre, apellidos, nif, etc
        nombre: document.getElementById('nombre').value,
        apellidos: document.getElementById('apellidos').value,
        nif: document.getElementById('nif').value,
        lenguaMaterna: lenguamaterna1,
        idiomas: idiomas
    });
    return this;
};

// Se crea (y se añade al Alumno) la funcion para construir el contenido de los datos famliares 
// cada valor de los datos personales se saca de las etiquetas HTML del formulario
// la mecanica es similar a la de buildDatosPersonales
AlumnoBuilder.prototype.buildFamiliares = function () {
    var selectIdiomasConocidos = document.getElementById('idiomasConocidos');
    var opcionesIdiomasConocidos = selectIdiomasConocidos.selectedOptions;
    var idiomasConocidos = [];
    for (var i = 0; i < opcionesIdiomasConocidos.length; i++) {
        idiomasConocidos.push(opcionesIdiomasConocidos[i].innerHTML);
    }

    var select = document.getElementById('profesion2');
    var profesion = select.options[select.selectedIndex].text;

    var select = document.getElementById('ciudadNacimiento');
    var ciudadnacimiento = select.options[select.selectedIndex].text;

    var select = document.getElementById('lenguamaterna2');
    var lenguamaterna2 = select.options[select.selectedIndex].text;

    this.alumno.setFamiliares({
        nombre: document.getElementById('nombre2').value,
        apellidos: document.getElementById('apellido2').value,
        nif: document.getElementById('nif2').value,
        profesion: profesion,
        ciudadNacimiento: ciudadnacimiento,
        lenguaMaterna: lenguamaterna2,
        idiomasConocidos: idiomasConocidos
    });
    return this;
};

// Se crea (y se añade al Alumno) la funcion para construir el contenido de los datos direccion 
// cada valor de los datos personales se saca de las etiquetas HTML del formulario
// la mecanica es similar a la de buildDatosPersonales
AlumnoBuilder.prototype.buildDireccion = function () {
    var select = document.getElementById('pais');
    var pais = select.options[select.selectedIndex].text;

    var select = document.getElementById('provincia');
    var provincia = select.options[select.selectedIndex].text;

    var select = document.getElementById('poblacion');
    var poblacion = select.options[select.selectedIndex].text;

    this.alumno.setDireccion({
        pais: pais,
        provincia: provincia,
        poblacion: poblacion,
        direccionCompleta: document.getElementById('direccionC').value,
        codigoPostal: document.getElementById('codigoP').value
    });
    return this;
};
// Se crea (y se añade al Alumno) la funcion para construir el contenido de los datos academicos 
// cada valor de los datos personales se saca de las etiquetas HTML del formulario
// la mecanica es similar a la de buildDatosPersonales
AlumnoBuilder.prototype.buildDatosAcademicos = function () {
    var select = document.getElementById('idiomasEstudiados');
    var selectedOptions = select.selectedOptions;
    var selectedValues = [];
    for (var i = 0; i < selectedOptions.length; i++) {
        selectedValues.push(selectedOptions[i].innerHTML);
    }

    this.alumno.setDatosAcademicos({
        colegioProcedencia: document.getElementById('colP').value,
        nivelEstudios: document.getElementById('nivelEstudios').value,
        idiomasEstudiados: selectedValues,
        nivelEstudiosSolicitado: document.getElementById('estudiosSolicitado').value
    });
    return this;
};
// Se crea (y se añade al Alumno) la funcion para construir el contenido de los datos medicos 
// cada valor de los datos personales se saca de las etiquetas HTML del formulario
// la mecanica es similar a la de buildDatosPersonales
AlumnoBuilder.prototype.buildInformacionMedica = function () {
    var selectAlergias = document.getElementById('alergias');
    var opcionesSeleccionadas = selectAlergias.selectedOptions;
    var valergias = [];
    for (var i = 0; i < opcionesSeleccionadas.length; i++) {
        valergias.push(opcionesSeleccionadas[i].innerHTML);
    }

    this.alumno.setInformacionMedica({
        alergias: valergias,
        medicacionActual: document.getElementById('medAct').value
    });
    return this;
};


// Función para mostrar el resumen en una Ventana modal
function mostrarResumen(alumno) {

    // creamos un texto HTML con los valores del objeto alumno recibido por parametro
    let resumen = `
    <h2>Resumen de la informacion suministrada del Alumno</h2>
    <h3>Datos Personales</h3>
    <p>Nombre: ${alumno.datosPersonales.nombre} ${alumno.datosPersonales.apellidos}</p>
    <p>NIF: ${alumno.datosPersonales.nif}</p>
    <p>Lengua Materna: ${alumno.datosPersonales.lenguaMaterna}</p>
    <p>Idiomas: ${alumno.datosPersonales.idiomas.join(', ') || 'Ninguno'}</p>

    <h3>Familiares</h3>
    <p>Nombre: ${alumno.familiares.nombre} ${alumno.familiares.apellidos}</p>
    <p>NIF: ${alumno.familiares.nif}</p>
    <p>Profesión: ${alumno.familiares.profesion}</p>
    <p>Ciudad Nacimiento: ${alumno.familiares.ciudadNacimiento}</p>
    <p>Lengua Materna: ${alumno.familiares.lenguaMaterna}</p>
    <p>Idiomas conocidos: ${alumno.familiares.idiomasConocidos.join(', ') || 'Ninguno'}</p>

    <h3>Dirección</h3>
    <p>${alumno.direccion.direccionCompleta}, ${alumno.direccion.poblacion}</p>
    <p>${alumno.direccion.provincia}, ${alumno.direccion.pais}</p>
    <p>Código Postal: ${alumno.direccion.codigoPostal}</p>

    <h3>Datos Académicos</h3>
    <p>Colegio de Procedencia: ${alumno.datosAcademicos.colegioProcedencia}</p>
    <p>Nivel de Estudios: ${alumno.datosAcademicos.nivelEstudios}</p>
    <p>Idiomas estudiados: ${alumno.datosAcademicos.idiomasEstudiados.join(', ') || 'Ninguno'}</p>
    <p>Nivel Solicitado: ${alumno.datosAcademicos.nivelEstudiosSolicitado}</p>

    <h3>Información Médica</h3>
    <p>Alergias: ${alumno.informacionMedica.alergias.join(', ') || 'Ninguna'}</p>
    <p>Medicación Actual: ${alumno.informacionMedica.medicacionActual}</p>
     `;

    // creamos una etiqueta DIV con posicion fija (position = 'fixed')
    // se mostrar centrada en la pantalla
    let modal = document.createElement('div');
    modal.style.position = 'fixed';
    modal.style.left = '0';
    modal.style.top = '0';
    modal.style.width = '100%';
    modal.style.height = '100%';
    modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
    modal.style.display = 'flex';
    modal.style.justifyContent = 'center';
    modal.style.alignItems = 'center';

    // creamos otro div que tiene el contenido del resumen
    let modalContent = document.createElement('div');
    modalContent.style.backgroundColor = '#fff';
    modalContent.style.padding = '20px';
    modalContent.style.borderRadius = '5px';
    modalContent.style.maxWidth = '80%';
    modalContent.style.maxHeight = '80%';
    modalContent.style.overflow = 'auto';
    modalContent.innerHTML = resumen;

    // metemos el segundo div dentro del primero
    modal.appendChild(modalContent);
    // añadimos el primer div al body del HTML
    document.body.appendChild(modal);

    // hacemos un listener al div del contenido del resumen
    modal.onclick = function () {
        // si hacen click en el, eliminamos el div
        document.body.removeChild(modal);
    };
}
